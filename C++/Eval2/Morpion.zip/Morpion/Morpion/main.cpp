//
//  main.cpp
//  Morpion
//
//  Created by Corentin Bringer on 23/11/2020.
//

#include <iostream>
#include "display.hpp"
#include "ia.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    char tabMorpion[9] = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};
    int choixCase = 0;
    
    cout << "Affichage grille vide:" << endl;
    displayEmptyGrid();
    
    do {
        choixCase = displayQuestion();
    } while(gameStateCheck(tabMorpion) == 'c');
    
    return 0;
}
